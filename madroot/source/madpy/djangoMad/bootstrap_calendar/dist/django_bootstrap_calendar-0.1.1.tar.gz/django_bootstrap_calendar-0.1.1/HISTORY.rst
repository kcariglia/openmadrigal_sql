.. :changelog:

History
-------

0.1.0 (2013-08-15)
++++++++++++++++++

* First release on PyPI.