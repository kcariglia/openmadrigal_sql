Put files in here you want to refer to from multiple places in your Madrigal distribution.  

They can be refered with url "/static/siteSpecific/<filename>"