"""Directory of all modules related to madrigal user interface."""
