"""Top level directory of all python modules related to Madrigal."""
