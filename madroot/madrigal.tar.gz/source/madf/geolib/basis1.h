C     Written by Shunrong Zhang
C     Imported into Madrigal from modelRecovery/fullAnalytic/
C     basis1.h on 10/21/2005 - Was revision 1.1.1.1
C
C     $Id: basis1.h 3304 2011-01-17 15:25:59Z brideout $
C
C     ..
C     .. Common blocks ..
      COMMON /SPFTCM/T,KS
      INTEGER KS
      DOUBLE PRECISION T(KNOTSMAX)
